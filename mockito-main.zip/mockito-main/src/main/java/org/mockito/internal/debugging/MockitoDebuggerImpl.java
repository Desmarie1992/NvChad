/*
 * Copyright (c) 2007 Mockito contributors
 * This program is made available under the terms of the MIT License.
 */
package org.mockito.internal.debugging;

import static java.util.Arrays.asList;

import java.util.List;

import org.mockito.MockitoDebugger;
import org.mockito.internal.invocation.UnusedStubsFinder;
import org.mockito.internal.invocation.finder.AllInvocationsFinder;
import org.mockito.invocation.Invocation;

public class MockitoDebuggerImpl implements MockitoDebugger {

    private final UnusedStubsFinder unusedStubsFinder = new UnusedStubsFinder();

    /**
     * TODO: when MockitoDebugger is deleted, delete this implementation, too
     */
    @Deprecated
    public String printInvocations(Object... mocks) {
        String out = "";
        List<Invocation> invocations = AllInvocationsFinder.find(asList(mocks));
        out += line("********************************");
        out += line("*** Mockito interactions log ***");
        out += line("********************************");
        for (Invocation i : invocations) {
            out += line(i.toString());
            out += line(" invoked: " + i.getLocation());
            if (i.stubInfo() != null) {
                out += line(" stubbed: " + i.stubInfo().stubbedAt());
            }
        }

        invocations = unusedStubsFinder.find(asList(mocks));
        if (invocations.isEmpty()) {
            return print(out);
        }
        out += line("********************************");
        out += line("***       Unused stubs       ***");
        out += line("********************************");

        for (Invocation i : invocations) {
            out += line(i.toString());
            out += line(" stubbed: " + i.getLocation());
        }
        return print(out);
    }

    private String line(String text) {
        return text + "\n";
    }

    private String print(String out) {
        System.out.println(out);
        return out;
    }
}
