/*
 * Copyright (c) 2007 Mockito contributors
 * This program is made available under the terms of the MIT License.
 */

/**
 * This package should be open to public once verification API is fully finished.
 */
package org.mockito.internal.verification.api;
