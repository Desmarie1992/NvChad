/*
 * Copyright (c) 2007 Mockito contributors
 * This program is made available under the terms of the MIT License.
 */

/**
 * Verification logic.
 */
package org.mockito.internal.verification;
